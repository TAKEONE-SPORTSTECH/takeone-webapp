# Handoff: Camera Screen — Record + Live Broadcast ("Tally Frame")

## Overview
Camera screen for a Flutter app that records locally and broadcasts live simultaneously. All REC/LIVE/bout start-stop commands are **pushed from a server** — the screen has NO start/stop buttons. It is a status display plus camera-only controls (zoom, settings). The signature concept is the **Tally Frame**: the screen's edge is the primary indicator (gold glow = on air, blinking red corner ticks = recording), readable from meters away with zero pixels over the video.

## About the Design Files
The bundled `Camera Layout Options.dc.html` is a **design reference created in HTML** — a static mock showing intended look and behavior, not production code. Recreate it in **Flutter** using the app's existing patterns (widgets, state management). The chosen direction is option **2a "Tally Frame"** (top section of the file). Options 1a/1b/1c below it are earlier explorations kept for reference.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final. Recreate pixel-close, adapting glass blur to Flutter (`BackdropFilter` + `ImageFilter.blur`).

## Design Tokens
Colors:
- Navy deep (backgrounds/scrim): `#0B132B`; panel navy: `#0E1730`
- Navy primary (light-UI text): `#1E2C4F`
- Gold (LIVE, selection, accents): `#D8B25F`; gold light: `#EDCD85`
- Red (REC, critical): `#E6455A`
- Green (healthy): `#4AC97E`; light green text: `#A9E6C3`
- Amber (degraded): `#E0A33C`; amber text: `#F4CD7E`
- Text primary on dark: `#EEF1F6`; secondary: `#C6CEDE`; muted: `#8B96AD`; faint: `#6F7D9C`
- Glass fill: `rgba(11,19,43,0.35)` (drawer `0.45`) + blur 10–14px + border `rgba(255,255,255,0.12–0.14)`

Typography: Poppins (400/500/600/700). Timers/numbers use tabular figures. Labels are uppercase, letter-spacing 0.1–0.14em, 10–12px. Timer digits 15px/600.

Radii: pills `999px`, cards/drawer `14–16px`, buttons `8–10px`, screen frame `20px`.

## Screen Layout (landscape, full-bleed video underneath everything)

### 1. Tally frame (state indicator, drawn on bezel)
- **LIVE**: 3px solid border `rgba(216,178,95,0.9)` around entire screen + inner glow `inset 0 0 34px rgba(216,178,95,0.28)`. Steady (no blink).
- **REC**: four corner ticks, 26×26px, 3px stroke `#E6455A`, corner-radius 12px, blinking (opacity 1→0.25, 1.4s loop).
- Both can show simultaneously. Neither overlays the subject area.

### 2. Top-center unified status capsule
Glass pill, three segments divided by 1px `rgba(255,255,255,0.14)`:
- REC segment: tint `rgba(230,69,90,0.14)`, 9px blinking red dot (1.2s), "REC" 11px/700, timer `12:34` 15px/600 tabular.
- LIVE segment: tint `rgba(216,178,95,0.14)`, steady gold dot, "LIVE" in `#EDCD85`, own timer (timers are independent).
- Context segment: "MAT 1 · BOUT 14" 11px/600 `#C6CEDE`.
- Idle state: capsule collapses to "MAT 1 · STANDBY" only.

### 3. Top-left: server link chip
Glass pill, 7px green dot + "SERVER LINKED" 10px/600 uppercase `#8B96AD`. If the command channel drops: dot and label turn red and the tally frame pulses — this is the one failure requiring a human.

### 4. Left edge (vertically centered): audio VU meters
Glass rounded rect (radius 10), two vertical bars 5px wide, 120px tall area. Gradient bottom→top: green 0–62%, amber 62–85%, red 85–100% (bar height = level).

### 5. Bottom-left: stream health ring
Glass pill containing:
- 34px conic-gradient ring: filled fraction = actual bitrate / target, ring color = health (green/amber/red). Center disc `#0E1730` shows bitrate ("4.2M", 8.5px/700).
- Text: "STREAM HEALTHY" 11px/700 `#A9E6C3` + "29.9 fps · 48 ms · 0 lost" 10px `#8B96AD`.
- Health words: HEALTHY (green) / DEGRADED (amber) / RECONNECTING (amber) / OFFLINE (red), computed from sent-fps vs target, kbps, RTT, packet loss.
- Tap expands full telemetry. Amber/red states enlarge the ring and add a reason banner (e.g. "network limited · recording unaffected").

### 6. Bottom-right: resources
Two glass chips: "◉ 4h 12m left" (storage as TIME at current bitrate, not GB; amber under 30 min) and "🔋 100%" (amber <20%, red <10%).

### 7. Right rail: camera-only controls
Vertical glass rail (radius 14, 8px padding, 8px gap): zoom presets 1×/2×/4× (44×44, selected = gold tint `rgba(216,178,95,0.2)` + 1.5px gold border, gold text), divider, ⚙ settings button.

### 8. Settings drawer (opens left of the rail, 250px wide)
Glass panel `rgba(11,19,43,0.45)` blur 14, radius 16, padding 16–18px. Header "CAMERA SETTINGS" + ✕ close. Controls stacked with 14px gap; each has a label row (10px/600 uppercase muted) with current value right-aligned in gold:
- **AUTOFOCUS**: segmented Auto / Lock / Manual (32px tall; selected = gold tint + border).
- **BRIGHTNESS · EV**: slider −2…+2, gold filled track (4px), 16px gold-light thumb, value shown (e.g. "+0.3").
- **FRAME RATE**: segmented 24 / 30 / 60.
- **WHITE BALANCE**: segmented Auto / Indoor / Lock.
- **Stabilization**: toggle (38×22, gold when on, navy knob).
- Footnote 9.5px `#6F7D9C`: "Frame-rate changes apply at the next bout — the server owns REC/LIVE, so mid-stream switches are queued."

### 9. Rule-of-thirds grid
Optional overlay: 1px lines at 33.33%/66.66% both axes, `rgba(255,255,255,0.05)`.

## Interactions & Behavior
- No local start/stop of REC, LIVE, or bout — all transitions arrive via server push. Animate transitions in (REC ticks fade/scale in, capsule segment slides in) so the operator sees the server took control.
- ⚙ toggles the settings drawer (slide/fade from right, ~200ms ease-out). Tap outside or ✕ closes.
- Health chip tap expands full telemetry (fps sent, kbps, size, limited-by, thermal, lost, RTT).
- Escalation ladder: green = silent; amber = banner with reason; red = full-width banner + haptic. Errors never live only in small text.
- Zoom/AF/EV/WB apply immediately; frame-rate changes while streaming are queued for the next bout.
- Thermal: hidden when NONE; FAIR = amber chip; SERIOUS = red + suggest dropping 60→30 fps.

## State Management
State variables: `bout {id, mat, inProgress}`, `recState {active, elapsed}`, `liveState {active, elapsed}`, `serverLink {connected}`, `streamHealth {word, sentFps, targetFps, kbps, targetKbps, rttMs, lostPackets, limitedBy, thermal}`, `audioLevels [l, r]`, `storage {minutesLeft}`, `battery {pct}`, camera settings `{zoom, focusMode, ev, frameRate, whiteBalance, stabilization}`, UI `{drawerOpen, telemetryExpanded}`.
Server push (WebSocket or similar) drives bout/rec/live; telemetry updates ~1Hz; audio meters ~10–15Hz.

## Assets
None required — all indicators are drawn (dots, rings, bars). Icons used: ⚙ and ✕ (replace with the app's icon set), battery glyph.

## Files
- `Camera Layout Options.dc.html` — section "2a Tally Frame" (top) is the design to implement; annotation grid under it explains the four key concepts. Sections 1a/1b/1c are earlier explorations; the SPEC card at the bottom documents the indicator/status rules.
