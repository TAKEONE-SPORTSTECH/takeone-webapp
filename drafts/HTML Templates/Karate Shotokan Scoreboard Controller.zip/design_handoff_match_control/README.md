# Handoff: Karate Kumite Match Control (Scoreboard Controller)

## Overview
A tournament match-control screen for WKF-style karate kumite. An operator on a tatami uses it to run a bout: score points for AKA (red) and AO (blue), manage penalties and Senshu, run the bout timer, load bouts from the event database, manage participant photos, configure rules/sounds, and declare winners. Changes are meant to propagate live to the audience scoreboard screens on the same mat.

## About the Design Files
The file in this bundle (`Match Control.dc.html`) is a **design reference created in HTML** — a working prototype showing the intended look and behavior. It is NOT production code to copy directly. Your task is to **recreate this design in the target codebase's existing environment** (React, Vue, native, etc.) using its established patterns — or, if no environment exists yet, pick the most appropriate framework and implement it there. All state is currently in-memory; production must wire it to the event database and a realtime channel to the scoreboard displays.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions are final. Recreate pixel-perfectly.

## Global Frame
- The whole UI is a fixed **1920 × 1080 (16:9) stage** that scales uniformly to fit any window: `scale = min(vw/1920, vh/1080)`, centered both axes, letterboxed by `#0a0b10`. Nothing may scroll or clip at stage level.
- Stage background: `linear-gradient(120deg, #0a0b10 0%, #10121c 30%, #0a0b10 55%, #12101a 80%, #0a0b10 100%)`, `background-size: 300% 300%`, animated (`ambient`, 18s ease-in-out infinite, shifts background-position 0%→100%→0%).
- Two ambient blurred orbs behind content (pointer-events none): left red `radial-gradient(circle, rgba(179,18,31,.13), transparent 70%)` 540px circle at left:-120px top:240px, drifting `translate(70px,-40px)` over 16s; right blue `rgba(13,85,184,.15)` 560px at right:-120px top:180px drifting `translate(-60px,50px)` over 19s. Both `filter: blur(30px)`.
- Stage padding: `26px 36px 22px`; column gap 22px.

## Design Tokens
Colors:
- Background base: `#0a0b10`; panel: `#111320`; inset/sunken: `#0e1017`; control fill: `#1f2230`; alt fill: `#12141d`
- Lines: `#1f2230` (subtle), `#2a2e40` (stronger)
- Text: `#e8eaf2`; muted: `#7d8296`; faint: `#5c6175`; secondary text `#a7abbe`
- AKA red: `#b3121f`; red accent/text: `#ff6b78`; alarm red: `#ff3b47`
- AO blue: `#0d55b8`; blue accent/text: `#8ab4ff` (alt `#6ea8ff`, plate label `#2f7bdb`)
- Yellow (always solid, never transparent): `#ffe135`
- Green: `#7ae582`
Typography:
- Display/numerals: **Anton** (Google Fonts), used for scores, timer, stepper digits, bout numbers, avatar initials
- Everything else: **Barlow Condensed** 400–700
- Links: `a { color:#8ab4ff }`, hover `#ffe135`
Radii: buttons/fields 10–12px; panels 18px; modals 20px; Hajime/Bouts 16px; penalty cells 12px.
Scrollbars (everywhere): 10px wide, track `#0a0b10`, thumb `#2a2e40` rounded 8px with 2px track-colored border, hover thumb `#ffe135`; Firefox `scrollbar-width: thin; scrollbar-color: #2a2e40 #0a0b10`. Scrollable lists add `padding-right: 14px` so cards never touch the scrollbar.
Number inputs: native spin buttons hidden (`-webkit-appearance:none`, `appearance:textfield`).

## Screens / Views

### 1. Top bar
Single row, `align-items: flex-end`, gap 32px.
- Left, fixed: title "MATCH CONTROL" (Anton 34px, uppercase, letter-spacing .04em) over "WKF KUMITE" (18px, `#7d8296`, letter-spacing .18em, uppercase).
- Right: event info, **right-aligned flex row, gap 40px, each item sized to content** (no stretching): Tournament, Category, Match, Tatami, Round.
  - Each item: caption (19px, uppercase, letter-spacing .18em, `#7d8296`) above value (34px, weight 600, `#e8eaf2`, nowrap/ellipsis).
  - **Read-only plain text** — NOT input boxes. Values come from the event database and change only when a bout is loaded from Bouts.

### 2. Main grid
`grid-template-columns: 1fr 500px 1fr; gap: 22px; flex:1`.

#### AKA panel (left) and AO panel (right)
Card: `#111320`, 1px `#1f2230` border, **8px top border** in side color (`#b3121f` / `#0d55b8`), radius 18px, padding `24px 32px`, column gap 18px. **The AO panel is a full mirror image of AKA** (every horizontal row is row-reversed; labels right-aligned).
Row order top→bottom:
1. **Score plate**: gradient `linear-gradient(100deg, <side>22, #0a0b10 55%)` (260deg on AO), radius 12px, padding `10px 22px`. Side label ("AKA"/"AO") 30px weight 700, letter-spacing .28em, side color, text-shadow `0 0 26px <side>66`; AO label color `#2f7bdb`. Score: Anton 104px, tabular-nums, text-shadow `0 4px 30px rgba(0,0,0,.8)`.
2. **Scoring buttons** (column, gap 12px, fills remaining height — each button `flex:1`): "Yuko +1", "Waza-ari +2", "Ippon +3" in side color bg, white text, 32px weight 700, radius 12px; "Correct −1" in `#1f2230` with `#e8eaf2` text, 30px. Press feedback: `transform: scale(.96); filter: brightness(1.25)` on :active with 80ms transition.
3. **Penalty row**: caption "PENALTY" (19px, .2em, `#7d8296`, width 104px). Five equal buttons `C1 C2 C3 HC H` (flex:1, height 76px, Anton 30px, radius 12px). **No +/− buttons — each cell is the button**: tapping cell *i* sets the penalty level to *i+1*; tapping the current top level steps back one. States: inactive `#0a0b10` bg / `#5c6175` text / `#1f2230` border; active C1–C3 solid `#ffe135` bg / black text; active HC & H `#b3121f` bg / white text / `#ff3b47` border. Reaching H (level 5) = **Hansoku: bout ends immediately, opponent wins** (if the rule toggle is on).
4. **Senshu row**: caption + one wide toggle button (height 58px, 24px text, .16em). Off: `#1f2230` bg, `#7d8296` text, `#2a2e40` border. On: solid `#ffe135` bg, black text, plus pulsing glow (`box-shadow 0 0 12→28px rgba(255,225,53,.5→.95)`, 2s loop). Only one side can hold Senshu; setting one clears the other.
5. **Identity strip** (bottom, after 1px `#2a2e40` top border): a button opening the Participant pop-up for that side. Contains 42×56 (3:4) photo thumb (rounded 8, shows the cropped photo or ◎ glyph), 36×24 country flag, then name (24px w600, ellipsis) over "club · country" (16px `#7d8296`), then "VIEW ▾" hint. Mirrored on AO.

#### Center column (500px)
Card same as panels. Content top→bottom (column, gap 22px):
1. **Bouts button**: solid `#ffe135`, black text, styled exactly like Hajime (44px weight 700 uppercase, letter-spacing .12em, min-height 96px, radius 16px, flex:1.2), with an SVG double-chevron-down icon (24×24 viewBox, two `M5 6 L12 13 L19 6` / `M5 12 L12 19 L19 12` strokes, stroke-width 2.6, round caps, currentColor, 34px) on **both** sides of the label.
2. **Timer plate** (`#0a0b10`, radius 12): "BOUT TIMER" caption (19px, .32em), time m:ss (Anton 132px, tabular-nums), status word (32px w700, .28em): "YAME" yellow when stopped, "HAJIME" green `#7ae582` while running, "TIME" when expired.
3. **Hajime/Yame button**: full width, flex:1.2, min-height 96px; label and bg toggle — stopped: green `#7ae582` "HAJIME"; running: red `#ff6b78` "YAME". Black text, gloss overlay `linear-gradient(rgba(255,255,255,.28), rgba(255,255,255,0) 60%, rgba(0,0,0,.14))` over the bg color, shadow `0 8px 0 -2px rgba(0,0,0,.5)`. While running: pulsing glow animation (box-shadow bloom `rgba(255,107,120,.55→.95)`, 1.8s loop). Press: scale(.97).
4. **Button grid** 2×3, gap 12px, all equal (min-height 76px, 30px w700 uppercase, .1em, radius 12px, `#12141d` bg + 1px colored border):
   - "Introduction"/"Scoreboard" toggle — outlined `#8ab4ff` when idle; **solid `#8ab4ff` bg, black text** while the introduction is showing (label flips to "Scoreboard").
   - "End bout" — `#ff3b47` text, `rgba(255,59,71,.5)` border.
   - "Settings" — `#ffe135` text/border. | "Hardware" — `#e8eaf2` text, `#2a2e40` border.
   - "Reset" — transparent bg, `#ff6b78` text/border. | "Resync" — `#8ab4ff`; label becomes "Resynced ✓" for 1.5s after click.
5. Helper caption (16px `#5c6175`, centered): "Changes appear on the scoreboard instantly. If a screen looks stuck, resync reloads every board on this mat."

## Pop-ups (all: dark scrim `rgba(0,0,0,.6)`, centered `#111320` card, `#2a2e40` border, radius 20px, header row with uppercase title + ✕)

### Bouts (z 20)
1100px wide, height 900px capped at 94% of the stage. Scrollable list of bout rows from the event database. Row: grid `100px 180px 1fr 48px 1fr`, `#0a0b10` bg, radius 12, padding `20px 22px`, 30px text.
- Bout no (Anton, `#ffe135`), then round name (22px uppercase `#7d8296`) with **category line under it** (16px `#5c6175`): "Senior · −67 kg · Men".
- AKA cell is **right-aligned/mirrored** so both avatars meet beside the centered "vs" (`#5c6175`).
- Avatar: 48×64 **3:4 rounded rect** (radius 8, `#1f2230` bg, 2px side-color border) with Anton initials in side accent color (photo when available). Name (red `#ff6b78` / blue `#6ea8ff`, ellipsis) with club line under it: 24×16 flag + club name (17px `#7d8296`).
- Clicking a row loads it onto the board: sets match no, fighter names/clubs/countries, clears scores/penalties/senshu/photos, resets timer. Footer hint: "Click a match to load it onto the board." (20px `#5c6175`).

### Settings (z 21) — tabbed
1020px wide. **Tab bar** under the header: equal-width buttons "Rules | Timer | Sounds" (20px w700 uppercase); active tab solid `#ffe135`/black, inactive `#12141d`/`#7d8296`/`#2a2e40` border. Below tabs, one panel at a time; **"Apply" button** (24px, solid `#ffe135`, black text, radius 14) always at the bottom, then note: "Rule changes apply immediately. The clock only resets if you changed the bout duration."
- **Rules tab** — checkbox rows (row: `#0e1017` bg, `#1f2230` border, radius 12, padding 12 16; checkbox 30×30 radius 8, checked solid `#ffe135` with black ✓, unchecked `#1f2230`/`#2a2e40`; title 20px w600 + hint 15px `#5c6175`):
  1. Senshu rule — "First unopposed point breaks a tie"
  2. Auto Senshu on first score — "Whoever scores first gets Senshu automatically"
  3. Win by penalties — "5th penalty (Hansoku) — the opponent wins the bout"
  4. Atoshi baraku warning — "Timer flashes red and the alarm plays near the end"
  5. Time-up buzzer — "Sound when the clock reaches 0:00"
  6. **Win by point gap** — same row style but with the gap number input (width 80, Anton 26px, `#ffe135` text) inline at the right of the row; input fades to 35% opacity when unchecked. Hint mentions "WKF rule: 8".
- **Timer tab**: "Bout duration (mm:ss)" — two plain number inputs (Anton 28px, centered, `#1f2230` bg, radius 12, no spinners, no steppers) with ":" between. "Warning starts at (mm:ss left)" — same pair but red `#ff6b78` digits; hint: flash + alarm start point, WKF atoshi baraku 0:15. Apply commits both; the clock resets only if duration changed.
- **Sounds tab**: **two-column grid** (gap 4px 28px) of 10 slots: Introduction music, Match start, Match end, Winner celebration, One point, Two points, Three points, Penalty, Time-up buzzer, Last-seconds alarm. Slot row: label (23px w600) over filename/status (17px; green `#7ae582` when set; otherwise "Nothing uploaded", or "Built-in beep" for the two buzzer slots), "CHOOSE" upload button (solid `#7ae582`, black, radius 10), red ✕ clear button (visible only when a file is set).

### Participant (z 19) — opened from a side's identity strip
640px. Header: 14×36 side-color bar + "AKA — PARTICIPANT" in side accent (`#ff6b78`/`#8ab4ff`). Content row: **photo box 210×280 (locked 3:4)**, side-color border, radius 14 — the photo or ◎ + "PHOTO" placeholder; clicking opens the Cropper. Right column: Name (26px w600), Club (24px), "Country · from club" with 42×28 flag — **all read-only display boxes** (`#0a0b10` bg, `#1f2230` border): these values come from the tournament database; only the photo is editable. Note text says exactly that. Green "DONE" button closes.

### Photo cropper (z 25)
520px. Title "PHOTO — <SIDE> · <Name>" in side accent. Viewport 330×440 (3:4), `#0a0b10`, 1px `#2a2e40`, radius 10, `touch-action:none`, with a 2px `#ffe135`-tinted inner frame when an image is loaded. Behavior:
- "UPLOAD" (blue-outlined) file input → image loads **as an object URL** (see Implementation notes), fitted cover (base scale = max(330/nw, 440/nh)), centered.
- **Drag to pan** (pointer capture; divide pointer deltas by the stage scale), **Zoom slider** 1–4, **Tilt slider** −180…180° (shows degrees). Transform order: translate(center + x,y) → rotate → scale(base·zoom).
- "CROP & SAVE" (green, 40% opacity until an image exists) renders the viewport to a 600×800 JPEG canvas (fill `#0a0b10` first, then same transform math ×600/330) and stores it as the participant photo (thumb + participant box + future bout rows). "REMOVE" clears the photo. Both return to the Participant pop-up (so does ✕ on cropper and country picker).

### End bout (z 22)
760px. "How did this bout end?" (`#ffe135`). Big "AWARD BY SCORE" card (green-tinted `#0f1a12`, `rgba(122,229,130,.45)` border) with subtitle naming the leader, score, and "by Senshu" if tied on senshu — disabled message when level with no senshu. Divider. "OR DECLARE THE WINNER": AKA/AO selector buttons (2px accent border when selected), reason chips: Hansoku, Shikkaku, Kiken, Medical, No show, Other (selected = `#ffe135` border), optional note input (200 chars), then "DECLARE THIS WINNER" (`#ff6b78` bg, black text; 40% opacity until side + reason chosen). Footer note about the declared winner overriding the score.

### Winner overlay (z 30)
Full-stage scrim `rgba(0,0,0,.72)`. Card with 10px top border in winner color, side label "AKA · WINNER" (24px, .32em), name (Anton 72px uppercase), detail line (reason · score, 26px `#a7abbe`), buttons "RECORD RESULT & NEXT MATCH" (green) and "BACK" (`#1f2230`). Entrance: scale .92→1 + fade (0.4s cubic-bezier(.2,.8,.2,1)); a soft yellow light sweep (34%-wide skewed gradient, `rgba(255,225,53,.08)`) loops across the card every 2.6s.

### Hardware (z 21)
640px placeholder: ⌁ glyph, "No devices connected on this mat yet.", caption "Connected scoreboards, buzzers and referee remotes will appear here."

## Interactions & Behavior (rules engine)
- **Points**: Yuko +1, Waza-ari +2, Ippon +3, Correct −1 (floor 0). Ignored once a winner exists.
- **Auto Senshu**: if the rule + auto toggle are on and both scores are 0 with no senshu held, the first scoring side receives Senshu.
- **Point-gap win**: if enabled and |aka−ao| ≥ gap (default 8), stop the clock and show the winner overlay ("Won by 8-point gap").
- **Penalties**: 5 levels; H triggers Hansoku auto-win for the opponent (if enabled).
- **Timer**: 1s interval countdown from bout duration (default 3:00). Hajime starts (plays "Match start" sound on the first start of a bout, only if a file is uploaded), Yame pauses. At `t = warning threshold` (default 0:15) play the last-seconds alarm and start red flashing (`atoshiFlash`: color alternates `#ff3b47`/`#e8eaf2`, 1s loop). At 0: stop, status "TIME", play the time-up buzzer (uploaded file, else a built-in 740Hz square-wave beep ~1.1s via WebAudio with exponential decay).
- **Award by score**: leader wins; tie broken by Senshu; otherwise must declare manually.
- **Declared winner** overrides score (reason recorded, e.g. "Declared · Kiken — note").
- **Match end sound** plays (if uploaded) when a winner is decided.
- **Record result & next**: clears scores/penalties/senshu/winner, resets timer to duration. **Reset** does the same without recording.
- **Resync**: broadcasts a reload to all boards on the mat (prototype fakes it with the 1.5s "Resynced ✓" label).

## Animations summary
| What | Trigger | Spec |
|---|---|---|
| Score pop | every score change | scale 1.4→1 + yellow flash, .45s cubic-bezier(.2,.8,.2,1); must re-trigger on EVERY change (alternate two identical keyframe names on a per-change counter, or re-key the node) |
| Button press | :active on score/penalty/Hajime | scale .94–.97 + brightness 1.25, 80ms |
| Hajime running glow | timer running | box-shadow bloom loop 1.8s |
| Timer glow | running, not in warning | soft text-shadow breathe 2.4s |
| Atoshi flash | t ≤ threshold | color flash 1s loop + alarm sound once |
| Senshu glow | senshu held | yellow box-shadow pulse 2s |
| Panel entrance | load | translateY(18px)+fade, .6s, stagger .05/.18/.3s |
| Ambient | always | gradient drift 18s; two blurred orbs 16/19s |
| Winner card | open | winIn .4s; looping light sweep 2.6s |

## State Management
Per side (aka/ao): `score, pen (0–5), senshu, name, club, country, countryCode, photo, popCounter`.
Match: `tournament, category, matchNo, tatami, round` (read-only, set by bout load).
Timer: `remaining, duration (s), running, timeUp, warningThreshold (s)`.
Rules: `senshuRule, autoSenshu, winByPenalties, atoshiWarn, timeUpBuzzer, gapOn, gap`.
Sounds: 10 slots `{label, url} | null`.
UI: `activeModal (bouts | settings+tab | participant(side) | cropper(side) | endBout | hardware | winner)`, cropper `{src, naturalW/H, zoom, rotation, x, y}`, end-bout `{side, reason, note}`.
Production: match/bout/participant data and result recording go to the event database; board state changes publish to the mat's scoreboard displays in realtime (websocket or similar); "Resync" forces board reloads.

## Implementation notes / gotchas (learned building the prototype)
- **Object URLs, not data URLs**, for uploaded photos/sounds if styles are ever serialized through CSS strings (a `data:` URL's `;base64` semicolon breaks naive style parsing; blob URLs are safe). Revoke stale URLs in production.
- Pointer-drag deltas in the cropper must be divided by the stage scale factor.
- Crop canvas math: scale context by (output/viewport), translate to viewport center + pan, rotate, scale by baseCover×zoom, draw image centered at −natural/2.
- Restarting a CSS animation on a value change requires re-keying or alternating between two identical keyframes — animation-name unchanged means no replay.
- Keep the two mm:ss inputs clamped 0–59; hide native number spinners.
- Sounds "Time-up buzzer" and "Last-seconds alarm" fall back to the built-in beep; all other slots are silent unless a file is uploaded.
- All fonts via Google Fonts: Anton (400), Barlow Condensed (400–700).

## Assets
- Country flags: `https://flagcdn.com/w320/<iso2>.png` (e.g. `bh.png`), rendered as cover backgrounds with 1px `rgba(255,255,255,.25)` border, radius 3–4px.
- No other external assets; icons are inline SVG (double chevron) and glyphs (◎, ⌁, ✕, ✓).

## Files
- `Match Control.dc.html` — the complete working prototype (markup + logic in one file).
